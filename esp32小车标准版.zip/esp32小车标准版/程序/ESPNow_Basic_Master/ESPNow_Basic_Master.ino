#include <esp_now.h>
#include <WiFi.h>
#include <U8g2lib.h>
U8G2_SSD1306_128X64_NONAME_1_HW_I2C u8g2(U8G2_R2, U8X8_PIN_NONE);

int x=0;
int y=0;

uint8_t broadcastAddress[] = {0x0C,0xDC,0x7E,0x62,0x9D,0x20};
// REPLACE WITH YOUR RECEIVER MAC Address 
typedef struct struct_message {
   char character[100];
   int integer;
} struct_message;
 
struct_message message;
 
void data_sent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.print("\r\nStatus of Last Message Sent:\t");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
}
 
void setup() {
  u8g2.setI2CAddress(0x3C*2);
  u8g2.begin();
  u8g2.enableUTF8Print();
  u8g2.firstPage();
  do
  {
    u8g2.setFont(u8g2_font_timR18_tf);
    u8g2.setFontPosTop();
    u8g2.setCursor(0,20);
    u8g2.print("master on");
  }while(u8g2.nextPage());

  Serial.begin(115200);
  WiFi.mode(WIFI_STA);

 pinMode(19,INPUT);

  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }
 
  esp_now_register_send_cb(data_sent);
  
  esp_now_peer_info_t peerInfo;
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;     
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    Serial.println("Failed to add peer");
    return;
  }
}
void loop() {
 x=analogRead(0) ;
 y=analogRead(1) ;

 if(2000<x<4000){
    message.integer=0;
    }
 if(2000<y<4000){
    message.integer=0;
    }
if (x > 4000) {
    Serial.println("1");
    message.integer=1;// 向接入点发送字符'1'
   
  } 
if (x < 2000) {
    Serial.println("2");
    message.integer=2;
    
  }  
if (y > 4000) {
    Serial.println("3");
    message.integer=3;// 向接入点发送字符'3'
  } 
if (y < 1200) {
    Serial.println("4");
    message.integer=4; // 向接入点发送字符'4'
  }    



  
  esp_err_t outcome = esp_now_send(broadcastAddress, (uint8_t *) &message, sizeof(message));
   
  if (outcome == ESP_OK) {
    Serial.println("Mesage sent successfully!");
  }
  else {
    Serial.println("Error sending the message");
  }
  delay(2000);
}
