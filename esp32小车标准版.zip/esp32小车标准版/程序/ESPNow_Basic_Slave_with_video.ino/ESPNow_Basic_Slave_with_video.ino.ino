#include "esp_camera.h"
#include <WiFi.h>
#include <esp_now.h>
#define CAMERA_MODEL_AI_THINKER // Has PSRAM
#include "camera_pins.h"

typedef struct struct_message {
    char character[100];
    int integer;
} struct_message;
 struct_message message;
 
void data_receive(const uint8_t * mac, const uint8_t *incomingData, int len) {
  memcpy(&message, incomingData, sizeof(message));
  // Serial.print("Bytes received: ");
  //Serial.println(len);
  //Serial.print("Char: ");
  //Serial.println(message.character);
  //Serial.print("Int: ");
  //Serial.println(message.integer);
}


const char* ssid = "RedmiK40";
const char* password = "qwer1234";

void startCameraServer();
void setupLedFlash(int pin);

void setup() {
  Serial.begin(115200);
  Serial.setDebugOutput(true);
  Serial.println();
      WiFi.mode(WIFI_STA);
      pinMode(4,OUTPUT);
      pinMode(2,OUTPUT);
      pinMode(14,OUTPUT);
      pinMode(15,OUTPUT);

      if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }
  
  esp_now_register_recv_cb(data_receive);

 
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.frame_size = FRAMESIZE_UXGA;
  config.pixel_format = PIXFORMAT_JPEG; // for streaming
  //config.pixel_format = PIXFORMAT_RGB565; // for face detection/recognition
  config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
  config.fb_location = CAMERA_FB_IN_PSRAM;
  config.jpeg_quality = 12;
  config.fb_count = 1;
  
  // if PSRAM IC present, init with UXGA resolution and higher JPEG quality
  //                      for larger pre-allocated frame buffer.
  if(config.pixel_format == PIXFORMAT_JPEG){
    if(psramFound()){
      config.jpeg_quality = 10;
      config.fb_count = 2;
      config.grab_mode = CAMERA_GRAB_LATEST;
    } else {
      // Limit the frame size when PSRAM is not available
      config.frame_size = FRAMESIZE_SVGA;
      config.fb_location = CAMERA_FB_IN_DRAM;
    }
  } else {
    // Best option for face detection/recognition
    config.frame_size = FRAMESIZE_240X240;
#if CONFIG_IDF_TARGET_ESP32S3
    config.fb_count = 2;
#endif
  }

#if defined(CAMERA_MODEL_ESP_EYE)
  pinMode(13, INPUT_PULLUP);
  pinMode(14, INPUT_PULLUP);
#endif

  // camera init
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x", err);
    return;
  }

  sensor_t * s = esp_camera_sensor_get();
  // initial sensors are flipped vertically and colors are a bit saturated
  if (s->id.PID == OV3660_PID) {
    s->set_vflip(s, 1); // flip it back
    s->set_brightness(s, 1); // up the brightness just a bit
    s->set_saturation(s, -2); // lower the saturation
  }
  // drop down frame size for higher initial frame rate
  if(config.pixel_format == PIXFORMAT_JPEG){
    s->set_framesize(s, FRAMESIZE_QVGA);
  }

#if defined(CAMERA_MODEL_M5STACK_WIDE) || defined(CAMERA_MODEL_M5STACK_ESP32CAM)
  s->set_vflip(s, 1);
  s->set_hmirror(s, 1);
#endif

#if defined(CAMERA_MODEL_ESP32S3_EYE)
  s->set_vflip(s, 1);
#endif

// Setup LED FLash if LED pin is defined in camera_pins.h
#if defined(LED_GPIO_NUM)
  setupLedFlash(LED_GPIO_NUM);
#endif

  WiFi.begin(ssid, password);
  WiFi.setSleep(false);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("WiFi connected");

  startCameraServer();

  Serial.print("Camera Ready! Use 'http://");
  Serial.print(WiFi.localIP());
  Serial.println("' to connect");
}

void loop() {
  if (message.integer == 1) {  // 如果接收到字符'a'
      // 控制两个电机都正转的代码（根据实际硬件连接修改GPIO引脚）
      Serial.println("1");
      digitalWrite(4, HIGH);  // 第一个电机正转
      digitalWrite(2, LOW);
      digitalWrite(14, HIGH);  // 第二个电机正转
      digitalWrite(15, LOW);
      delay(500);
      
    } 
    if (message.integer == 2) {  // 如果接收到字符'b'
      // 控制一个电机正转，另一个反转的代码（根据实际硬件连接修改GPIO引脚）
      digitalWrite(4, LOW);  // 第一个电机反转
      digitalWrite(2, HIGH);
      digitalWrite(14, LOW);  // 第二个电机反转
      digitalWrite(15, HIGH);
      delay(500);
    } 
    if (message.integer == 3) {  // 如果接收到字符'c'
      // 控制一个电机正转，另一个反转的代码（根据实际硬件连接修改GPIO引脚）
      digitalWrite(4, HIGH);  // 第一个电机正转
      digitalWrite(2, LOW);
      digitalWrite(14, LOW);  // 第二个电机反转
      digitalWrite(15, HIGH);
      delay(500);
    }
    if (message.integer == 4) {  // 如果接收到字符'a'
      // 控制两个电机都正转的代码（根据实际硬件连接修改GPIO引脚）
      digitalWrite(4, LOW);  // 第一个电机反转
      digitalWrite(2, HIGH);
      digitalWrite(14, HIGH);  // 第二个电机正转
      digitalWrite(15, LOW);
      delay(500);
    } 
    if (message.integer == 0) {  // 如果接收到字符'a'
      // 控制两个电机都正转的代码（根据实际硬件连接修改GPIO引脚）
      digitalWrite(4, LOW);  // 第一个电机反转
      digitalWrite(2, LOW);
      digitalWrite(14, LOW);  // 第二个电机正转
      digitalWrite(15, LOW);
      delay(500);
    } 
}
