#include <WiFi.h>
#include <AsyncUDP.h>
#include <Arduino.h>

AsyncUDP udp;               //UDP网络协议导入
AsyncUDP Rudp;

const char* ssid = "RedmiK40";
const char* password = "qwer1234";
char rBuff[18];
String inputString;                //字符串变量

void setup() {
  Serial.begin(115200);
  Serial.setDebugOutput(true);
  Serial.println();
  WiFi.begin(ssid, password);
  WiFi.setSleep(false);
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("WiFi connected");

  pinMode(4,OUTPUT);
  pinMode(5,OUTPUT);
  pinMode(16,OUTPUT);
  pinMode(17,OUTPUT);
  pinMode(18,OUTPUT);
  pinMode(19,OUTPUT);
  pinMode(12,OUTPUT);
  pinMode(14,OUTPUT);

  while (!Rudp.listen(10011)) //等待本机udp监听端口设置成功,用于接收上位端发送过来的数据
{
    Serial.println("waiting");    
}
Rudp.onPacket([](AsyncUDPPacket Rpacket){
//注册一个端口10011的数据包接收事件，可异步接收数据，用于接收上位机发送过来的数据

for (int i = 0; i < Rpacket.length(); i++)
    {
      rBuff[i] = (char) * (Rpacket.data() + i);
    }
    inputString = String(rBuff);
    if (inputString.indexOf("are you here") != -1)
    {
         
         if (udp.connect(Rpacket.remoteIP(), 10000)) //检查网络连接是否存在,这取决于上位机是否连接,这里条件是如果有连接则处理,否则进入下一次loop.
         {
           udp.print("ok,it is me"); 
           //udp.write(fb->buf, max_packet_byte); //将图片分包发送
         }
        
    }
    });
    if (rBuff[0]=='1')
    {
      Serial.println("1");
      digitalWrite(4, HIGH);  // 第1个电机正转
      digitalWrite(5, LOW);
      digitalWrite(16, HIGH);  // 第2个电机正转
      digitalWrite(17, LOW);
      digitalWrite(18, HIGH);  // 第3个电机正转
      digitalWrite(19, LOW);
      digitalWrite(12, HIGH);  // 第4个电机正转
      digitalWrite(14, LOW);
    }
    if  (rBuff[0]=='2')
    {
      digitalWrite(4, LOW);  // 第1个电机反转
      digitalWrite(5, HIGH);
      digitalWrite(16, LOW);  // 第2个电机反转
      digitalWrite(17, HIGH);
      digitalWrite(18, LOW);  // 第3个电机反转
      digitalWrite(19, HIGH);
      digitalWrite(12, LOW);  // 第4个电机反转
      digitalWrite(14, HIGH);
    }
    if  (rBuff[0]=='3')
    {
      digitalWrite(4, HIGH);  // 第1个电机正转
      digitalWrite(5, LOW);
      digitalWrite(16, HIGH);  // 第2个电机正转
      digitalWrite(17, LOW);
      digitalWrite(18, LOW);  // 第3个电机反转
      digitalWrite(19, HIGH);
      digitalWrite(12, LOW);  // 第4个电机反转
      digitalWrite(14, HIGH);
    }
    if  (rBuff[0]=='4')
    {
      digitalWrite(4, LOW);  // 第1个电机反转
      digitalWrite(5, HIGH);
      digitalWrite(16, LOW);  // 第2个电机反转
      digitalWrite(17, HIGH);
      digitalWrite(18, HIGH);  // 第3个电机正转
      digitalWrite(19, LOW);
      digitalWrite(12, HIGH);  // 第4个电机正转
      digitalWrite(14, LOW);
    }
     if (rBuff[0]=='0')
    {
      digitalWrite(4, LOW);  // 第1个电机反转
      digitalWrite(5, LOW);
      digitalWrite(16, LOW);  // 第2个电机反转
      digitalWrite(17, LOW);
      digitalWrite(18, LOW);  // 第3个电机反转
      digitalWrite(19, LOW);
      digitalWrite(12, LOW);  // 第4个电机反转
      digitalWrite(14, LOW);
    }

}
// 假设在全局范围内定义了以下变量
unsigned long previousMillis = 0;  // 上一次检查WiFi连接的时间
const unsigned long interval = 10000;  // 检查间隔，例如10秒
int reconnectAttempts = 0;  // 重连尝试的次数
const int maxReconnectAttempts = 5;  // 最大重连尝试次数

//防止网络连接中断超时后再次连接网络
void loop() {
  unsigned long currentMillis = millis();   //获取当前机器运行时间
// 定时检查WIFI是否连接,如果无连接则重连
  if ((WiFi.status() != WL_CONNECTED) && (currentMillis - previousMillis >=interval)) {
    WiFi.disconnect();
    WiFi.reconnect();
    previousMillis = currentMillis;
  }
 
}
